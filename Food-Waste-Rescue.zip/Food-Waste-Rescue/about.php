
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>About Us | Food Waste Rescue</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
          rel="stylesheet">

    <!-- Existing Website CSS -->
    <link rel="stylesheet" href="css/style.css">

    <!-- New Page CSS -->
    <link rel="stylesheet" href="css/info-pages.css">
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg bg-white shadow-sm">
    <div class="container">

        <a class="navbar-brand fw-bold text-success d-flex align-items-center"
           href="index.php">

            <img src="hero-images/leaf-logo.png"
                 alt="Food Waste Rescue Logo"
                 class="brand-logo">

            <span>Food Waste Rescue</span>
        </a>

        <button class="navbar-toggler" type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNav"
                aria-controls="navbarNav"
                aria-expanded="false"
                aria-label="Toggle navigation">

            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">

            <ul class="navbar-nav ms-auto align-items-lg-center me-3">

                <li class="nav-item">
                    <a href="index.php" class="nav-link">Home</a>
                </li>

                <li class="nav-item">
                    <a href="how-it-works.php" class="nav-link">How It Works</a>
                </li>

                <li class="nav-item">
                    <a href="about.php" class="nav-link active">About</a>
                </li>

            </ul>

            <div>
                <a href="login.php"
                   class="btn btn-outline-success me-2">Login</a>

                <a href="register.php"
                   class="btn btn-success">Register</a>
            </div>

        </div>
    </div>
</nav>


<!-- ABOUT HERO -->
<section class="about-hero">
    <div class="container">

        <div class="row align-items-center">

            <div class="col-lg-7">

                <h1>About Food Waste Rescue</h1>

                <p class="lead">
                    Together for a Greener, Hunger-Free Community.
                </p>

                <p>
                    Good food should feed people, not landfills.
                    We aim to connect food donors with people
                    who can make use of surplus food.
                </p>

            </div>

            <div class="col-lg-5 text-center">

                <i class="bi bi-globe-asia-australia about-hero-icon"></i>

            </div>

        </div>

    </div>
</section>


<!-- OUR AIM -->
<section class="container py-5">

    <div class="row g-4">

        <div class="col-lg-7">

            <h2 class="section-heading">Our Aim</h2>

            <p>
                Food Waste Rescue is a web platform designed to
                redirect surplus food from restaurants, grocery
                stores and other food providers to individuals
                and organisations that can use it.
            </p>

            <p>
                Donors can list their surplus food, while
                Receivers can discover available food and
                request collections. Our goal is to make
                food redistribution easier and more organised.
            </p>

            <h2 class="section-heading mt-4">The Problem</h2>

            <p>
                Food businesses often have edible surplus food
                that is difficult to distribute quickly.
                At the same time, individuals and communities
                may need affordable or donated food.
            </p>

            <p>
                Without a simple way to connect both sides,
                perfectly usable food can end up being wasted.
                Food Waste Rescue aims to help bridge that gap.
            </p>

        </div>


        <!-- PROJECT CARD -->
        <div class="col-lg-5">

            <div class="about-project-card">

                <i class="bi bi-recycle about-card-icon"></i>

                <h3>About This Project</h3>

                <p>
                    Food Waste Rescue is a university web project
                    developed to demonstrate how technology can
                    help reduce food waste and support communities.
                </p>

                <p>
                    The website uses HTML, CSS, Bootstrap,
                    JavaScript, PHP and MySQL.
                </p>

                <a href="register.php" class="btn btn-success">
                    Join as a Donor or Receiver
                </a>

            </div>

        </div>

    </div>

</section>


<!-- MISSION AND VISION -->
<section class="mission-section py-5">

    <div class="container">

        <div class="row g-4">

            <div class="col-md-6">

                <div class="mission-card h-100">

                    <i class="bi bi-leaf-fill"></i>

                    <h3>Our Mission</h3>

                    <p>
                        To reduce food waste by connecting food
                        donors with individuals and organisations
                        that can use surplus food.
                    </p>

                </div>

            </div>


            <div class="col-md-6">

                <div class="mission-card h-100">

                    <i class="bi bi-eye-fill"></i>

                    <h3>Our Vision</h3>

                    <p>
                        A community where good food is valued,
                        unnecessary waste is reduced, and more
                        people have access to nutritious meals.
                    </p>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- WHY CHOOSE US -->
<section class="container py-5">

    <div class="text-center mb-4">

        <h2 class="section-heading">Why Food Waste Rescue?</h2>

        <p class="text-muted">
            Small actions can create a meaningful difference.
        </p>

    </div>

    <div class="row g-4">

        <div class="col-md-4">

            <div class="benefit-card text-center h-100">

                <i class="bi bi-recycle"></i>

                <h4>Reduce Food Waste</h4>

                <p>
                    Help redirect surplus food away from
                    landfills and toward people who need it.
                </p>

            </div>

        </div>


        <div class="col-md-4">

            <div class="benefit-card text-center h-100">

                <i class="bi bi-people-fill"></i>

                <h4>Support Communities</h4>

                <p>
                    Connect donors and receivers through
                    a shared community platform.
                </p>

            </div>

        </div>


        <div class="col-md-4">

            <div class="benefit-card text-center h-100">

                <i class="bi bi-globe"></i>

                <h4>Protect the Environment</h4>

                <p>
                    Encourage responsible food use and
                    more sustainable communities.
                </p>

            </div>

        </div>

    </div>

</section>


<!-- CALL TO ACTION -->
<section class="about-cta py-5">

    <div class="container text-center">

        <h2>Together, We Can Make a Difference</h2>

        <p>
            Join Food Waste Rescue and become part of the solution.
        </p>

        <a href="register.php" class="btn btn-light btn-lg">
            Get Involved
        </a>

    </div>

</section>


<!-- FOOTER -->
<footer class="text-center py-4">

    <p class="mb-0">
        Food Waste Rescue · Saving food, supporting communities.
    </p>

</footer>


<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
