
<?php
session_start();

if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Register | Food Waste Rescue</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
          rel="stylesheet">

    <!-- Existing CSS -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Registration CSS -->
    <link rel="stylesheet" href="css/register.css">
</head>

<body class="register-page">

<main class="register-container">

    <div class="register-card">

        <!-- Logo -->
        <a href="index.php" class="register-brand">

            <img src="hero-images/leaf-logo.png"
                 alt="Food Waste Rescue Logo">

            <span>Food Waste Rescue</span>

        </a>

        <h1>Create your account</h1>

        <p class="register-subtitle">
            Create your account to get started.
        </p>

        <!-- Registration Messages -->
        <?php if (isset($_GET["error"])): ?>

            <div class="alert alert-danger" role="alert">

                <?php
                $messages = [
                    "empty" => "Please fill in all required fields.",
                    "email" => "Please enter a valid email address.",
                    "duplicate" => "This email is already registered.",
                    "password" => "Password must contain at least 8 characters, including a letter and a number.",
                    "role" => "Please select a valid user type.",
                    "phone" => "Please enter a valid phone number.",
                    "csrf" => "Invalid form submission. Please try again.",
                    "failed" => "Registration failed. Please try again."
                ];

                echo htmlspecialchars(
                    $messages[$_GET["error"]] ?? "Something went wrong."
                );
                ?>

            </div>

        <?php endif; ?>

        <?php if (isset($_GET["success"])): ?>

            <div class="alert alert-success" role="alert">
                Registration successful! You can now log in.
            </div>

        <?php endif; ?>


        <!-- Registration Form -->
        <form action="backend/register_process.php"
              method="POST">

            <input type="hidden"
                   name="csrf_token"
                   value="<?php echo htmlspecialchars($_SESSION["csrf_token"]); ?>">

            <!-- Full Name -->
            <div class="mb-3">

                <label for="full_name" class="form-label">
                    Full Name
                </label>

                <input type="text"
                       class="form-control"
                       id="full_name"
                       name="full_name"
                       placeholder="Enter your full name"
                       maxlength="100"
                       autocomplete="name"
                       required>

            </div>


            <!-- Email -->
            <div class="mb-3">

                <label for="email" class="form-label">
                    Email Address
                </label>

                <input type="email"
                       class="form-control"
                       id="email"
                       name="email"
                       placeholder="Enter your email"
                       maxlength="150"
                       autocomplete="email"
                       required>

            </div>


            <!-- Phone -->
            <div class="mb-3">

                <label for="phone" class="form-label">
                    Phone Number
                </label>

                <input type="tel"
                       class="form-control"
                       id="phone"
                       name="phone"
                       placeholder="Enter your phone number"
                       maxlength="20"
                       autocomplete="tel"
                       required>

            </div>


            <!-- Password -->
            <div class="mb-3">

                <label for="password" class="form-label">
                    Password
                </label>

                <div class="password-wrapper">

                    <input type="password"
                           class="form-control"
                           id="password"
                           name="password"
                           placeholder="Enter your password"
                           minlength="8"
                           maxlength="72"
                           autocomplete="new-password"
                           required>

                    <button type="button"
                            id="togglePassword"
                            aria-label="Show password">

                        <i class="bi bi-eye"></i>

                    </button>

                </div>

                <div class="form-text">
                    At least 8 characters, with a letter and a number.
                </div>

            </div>


            <!-- User Type -->
            <fieldset class="mb-3">

                <legend class="form-label fs-6">
                    User Type
                </legend>

                <div class="form-check form-check-inline">

                    <input class="form-check-input"
                           type="radio"
                           name="role"
                           id="role-donor"
                           value="donor"
                           checked
                           required>

                    <label class="form-check-label"
                           for="role-donor">
                        Donor
                    </label>

                </div>

                <div class="form-check form-check-inline">

                    <input class="form-check-input"
                           type="radio"
                           name="role"
                           id="role-receiver"
                           value="receiver">

                    <label class="form-check-label"
                           for="role-receiver">
                        Receiver
                    </label>

                </div>

                <div class="form-text">
                    Donors post surplus food. Receivers request it.
                </div>

            </fieldset>


            <!-- Organisation Type -->
            <div class="mb-4">

                <label for="organisation_type"
                       class="form-label">

                    Business Type
                    <span class="text-secondary fw-normal">
                        (Optional)
                    </span>

                </label>

                <input type="text"
                       class="form-control"
                       id="organisation_type"
                       name="organisation_type"
                       maxlength="60"
                       placeholder="e.g. Restaurant Owner">

            </div>


            <!-- Submit -->
            <button type="submit"
                    class="btn btn-success w-100 register-button">

                Register

            </button>

        </form>


        <p class="login-link">
            Already have an account?
            <a href="login.php">Login</a>
        </p>

        <a href="index.php" class="back-home">
            <i class="bi bi-arrow-left"></i>
            Back to Home
        </a>

    </div>

</main>


<!-- Password Visibility -->
<script>

const passwordInput = document.getElementById("password");
const togglePassword = document.getElementById("togglePassword");

togglePassword.addEventListener("click", function () {

    const isPassword = passwordInput.type === "password";

    passwordInput.type = isPassword ? "text" : "password";

    this.innerHTML = isPassword
        ? '<i class="bi bi-eye-slash"></i>'
        : '<i class="bi bi-eye"></i>';

    this.setAttribute(
        "aria-label",
        isPassword ? "Hide password" : "Show password"
    );

});

</script>

</body>
</html>
