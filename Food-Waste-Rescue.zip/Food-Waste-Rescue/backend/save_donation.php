<?php

header("Content-Type: application/json");

require "db.php";

// Accept POST requests only
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);

    exit;
}

// Receive data from JavaScript
$foodName = trim($_POST["foodName"] ?? "");
$category = trim($_POST["category"] ?? "");
$quantity = filter_var(
    $_POST["quantity"] ?? null,
    FILTER_VALIDATE_INT
);
$donationType = $_POST["donationType"] ?? "";
$price = $_POST["price"] ?? "0";
$pickupLocation = trim($_POST["pickupLocation"] ?? "");
$donorName = trim($_POST["donorName"] ?? "");

// Validate required fields
$allowedCategories = [
    "vegetables",
    "bread",
    "meals",
    "fruits",
    "other"
];

if (
    $foodName === "" ||
    !in_array($category, $allowedCategories, true) ||
    $quantity === false ||
    $quantity === null ||
    $quantity < 1 ||
    !in_array($donationType, ["Free", "Paid"], true) ||
    $pickupLocation === "" ||
    $donorName === ""
) {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Please provide valid donation information."
    ]);

    exit;
}

// Validate price
if (
    !is_numeric($price) ||
    !is_finite((float) $price) ||
    ($donationType === "Paid" && (float) $price <= 0) ||
    ($donationType === "Free" && (float) $price != 0)
) {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Please enter a valid price."
    ]);

    exit;
}

// Free donations have a price of zero
$price = $donationType === "Paid"
    ? (float) $price
    : 0;

// Handle food image upload
if (
    !isset($_FILES["food_image"]) ||
    $_FILES["food_image"]["error"] !== UPLOAD_ERR_OK
) {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Please select a food image and try again."
    ]);

    exit;
}

$image = $_FILES["food_image"];

// Maximum image size: 5 MB
if ($image["size"] > 5 * 1024 * 1024) {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Image size must not exceed 5 MB."
    ]);

    exit;
}

// Check the actual image type
$finfo = new finfo(FILEINFO_MIME_TYPE);
$mimeType = $finfo->file($image["tmp_name"]);

$allowedTypes = [
    "image/jpeg" => "jpg",
    "image/png"  => "png",
    "image/webp" => "webp"
];

if (!isset($allowedTypes[$mimeType])) {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Only JPG, PNG, and WebP images are allowed."
    ]);

    exit;
}

// Save images in the existing images folder
$uploadDirectory = __DIR__ . "/../images/";

if (
    !is_dir($uploadDirectory) &&
    !mkdir($uploadDirectory, 0755, true)
) {
    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Could not create the image folder."
    ]);

    exit;
}

// Generate a unique filename
$filename = bin2hex(random_bytes(16))
    . "." . $allowedTypes[$mimeType];

$destination = $uploadDirectory . $filename;

// Move the uploaded image into the folder
if (!move_uploaded_file($image["tmp_name"], $destination)) {
    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Could not upload the food image."
    ]);

    exit;
}

// Store the relative image path
$imagePath = "images/" . $filename;

// Save donation and image path using a prepared statement
$sql = "INSERT INTO donations
        (food_name, category, quantity, donation_type,
         price, pickup_location, donor_name, image_path)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    if (file_exists($destination)) {
        unlink($destination);
    }

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Could not process the donation."
    ]);

    $conn->close();
    exit;
}

$stmt->bind_param(
    "ssisdsss",
    $foodName,
    $category,
    $quantity,
    $donationType,
    $price,
    $pickupLocation,
    $donorName,
    $imagePath
);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Donation saved successfully!",
        "id" => $conn->insert_id,
        "image_path" => $imagePath
    ]);
} else {
    // Remove the uploaded image if the database insertion fails
    if (file_exists($destination)) {
        unlink($destination);
    }

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Could not save the donation. Please try again."
    ]);
}

$stmt->close();
$conn->close();

?>