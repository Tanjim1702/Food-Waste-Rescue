
<?php

header("Content-Type: application/json");

require_once __DIR__ . "/auth.php";
require_once __DIR__ . "/db.php";

// Return a JSON response and stop execution.
function sendResponse($success, $message, $statusCode = 200, $extra = [])
{
    http_response_code($statusCode);

    echo json_encode(array_merge([
        "success" => $success,
        "message" => $message
    ], $extra));

    exit;
}

// Accept POST requests only.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    sendResponse(false, "Invalid request method.", 405);
}

// Verify login session.
if (
    !isset($_SESSION["user_id"]) ||
    !isset($_SESSION["user_role"]) ||
    !is_numeric($_SESSION["user_id"])
) {
    sendResponse(false, "Please log in before submitting a donation.", 401);
}

// Only donors can submit donations.
if ($_SESSION["user_role"] !== "Donor") {
    sendResponse(false, "You are not authorized to submit donations.", 403);
}

// Get authenticated donor information.
// Never trust donor identity submitted by the browser.
$donorId = (int) $_SESSION["user_id"];
$donorName = $_SESSION["user_name"] ?? "";

// Receive donation information.
$foodName = trim($_POST["foodName"] ?? "");
$category = trim($_POST["category"] ?? "");

$quantity = filter_var(
    $_POST["quantity"] ?? null,
    FILTER_VALIDATE_INT
);

$donationType = $_POST["donationType"] ?? "";
$priceInput = trim((string) ($_POST["price"] ?? "0"));
$pickupLocation = trim($_POST["pickupLocation"] ?? "");

// Validate required fields.
$allowedCategories = [
    "vegetables",
    "bread",
    "meals",
    "fruits",
    "other"
];

if (
    $foodName === "" ||
    strlen($foodName) > 150 ||
    !in_array($category, $allowedCategories, true) ||
    $quantity === false ||
    $quantity === null ||
    $quantity < 1 ||
    !in_array($donationType, ["Free", "Paid"], true) ||
    $pickupLocation === "" ||
    strlen($pickupLocation) > 255 ||
    $donorName === "" ||
    strlen($donorName) > 150
) {
    sendResponse(
        false,
        "Please provide valid donation information.",
        400
    );
}

// Validate price.
if (
    !is_numeric($priceInput) ||
    !is_finite((float) $priceInput) ||
    (float) $priceInput < 0 ||
    (float) $priceInput > 99999999.99 ||
    ($donationType === "Paid" && (float) $priceInput <= 0) ||
    ($donationType === "Free" && (float) $priceInput != 0)
) {
    sendResponse(false, "Please enter a valid price.", 400);
}

// Free donations always have zero price.
$price = $donationType === "Paid"
    ? (float) $priceInput
    : 0.00;


// =====================================
// HANDLE FOOD IMAGE UPLOAD
// =====================================

if (
    !isset($_FILES["food_image"]) ||
    $_FILES["food_image"]["error"] !== UPLOAD_ERR_OK
) {
    sendResponse(
        false,
        "Please select a food image and try again.",
        400
    );
}

$image = $_FILES["food_image"];

// Verify that this is a genuine uploaded file.
if (!is_uploaded_file($image["tmp_name"])) {
    sendResponse(false, "Invalid image upload.", 400);
}

// Maximum image size: 5 MB.
if ($image["size"] <= 0 || $image["size"] > 5 * 1024 * 1024) {
    sendResponse(
        false,
        "Image size must not exceed 5 MB.",
        400
    );
}

// Check the actual image MIME type.
$finfo = new finfo(FILEINFO_MIME_TYPE);
$mimeType = $finfo->file($image["tmp_name"]);

$allowedTypes = [
    "image/jpeg" => "jpg",
    "image/png"  => "png",
    "image/webp" => "webp"
];

if (!isset($allowedTypes[$mimeType])) {
    sendResponse(
        false,
        "Only JPG, PNG, and WebP images are allowed.",
        400
    );
}

// Confirm that the uploaded file is a valid image.
if (getimagesize($image["tmp_name"]) === false) {
    sendResponse(false, "The uploaded file is not a valid image.", 400);
}


// =====================================
// SAVE IMAGE
// =====================================

$uploadDirectory = __DIR__ . "/../images/";

if (
    !is_dir($uploadDirectory) &&
    !mkdir($uploadDirectory, 0755, true)
) {
    sendResponse(
        false,
        "Could not create the image folder.",
        500
    );
}

// Generate a unique filename.
$filename = bin2hex(random_bytes(16))
    . "." . $allowedTypes[$mimeType];

$destination = $uploadDirectory . $filename;

// Move uploaded image.
if (!move_uploaded_file($image["tmp_name"], $destination)) {
    sendResponse(
        false,
        "Could not upload the food image.",
        500
    );
}

// Relative image path stored in the database.
$imagePath = "images/" . $filename;


// =====================================
// SAVE DONATION TO DATABASE
// =====================================

// Important:
// quantity_available starts equal to quantity.
// donor_id comes from the authenticated session.

$sql = "INSERT INTO donations
        (
            food_name,
            category,
            quantity,
            quantity_available,
            donation_type,
            price,
            pickup_location,
            donor_name,
            donor_id,
            image_path
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {

    if (file_exists($destination)) {
        unlink($destination);
    }

    error_log("Donation preparation failed: " . $conn->error);

    sendResponse(
        false,
        "Could not process the donation.",
        500
    );
}

// Bind parameters.
$stmt->bind_param(
    "ssiisdssis",
    $foodName,
    $category,
    $quantity,
    $quantityAvailable,
    $donationType,
    $price,
    $pickupLocation,
    $donorName,
    $donorId,
    $imagePath
);

// Initialize available quantity.
$quantityAvailable = $quantity;


// Execute the insertion.
if ($stmt->execute()) {

    $donationId = $conn->insert_id;

    $stmt->close();
    $conn->close();

    sendResponse(
        true,
        "Donation saved successfully!",
        200,
        [
            "id" => $donationId,
            "image_path" => $imagePath
        ]
    );

} else {

    // Remove uploaded image if database insertion fails.
    if (file_exists($destination)) {
        unlink($destination);
    }

    error_log("Donation insertion failed: " . $stmt->error);

    $stmt->close();
    $conn->close();

    sendResponse(
        false,
        "Could not save the donation. Please try again.",
        500
    );
}

?>
