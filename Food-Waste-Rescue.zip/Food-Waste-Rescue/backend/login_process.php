
<?php

session_start();

require_once "db.php";

// Only accept POST requests.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../login.php");
    exit;
}

// Get login information.
$email = trim($_POST["email"] ?? "");
$password = $_POST["password"] ?? "";

// Check empty fields.
if ($email === "" || $password === "") {
    header("Location: ../login.php?error=empty");
    exit;
}

// Find user using a prepared statement.
$stmt = $conn->prepare(
    "SELECT id, name, email, password_hash, role
     FROM users
     WHERE email = ?"
);

$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 1) {

    $user = $result->fetch_assoc();

    if (password_verify($password, $user["password_hash"])) {

        // Regenerate session ID for security.
        session_regenerate_id(true);

        // Store user information.
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["user_name"] = $user["name"];
        $_SESSION["user_email"] = $user["email"];
        $_SESSION["user_role"] = $user["role"];

        // Redirect according to account role.
        switch ($user["role"]) {

            case "Donor":
                header("Location: ../donor/dashboard.php");
                exit;

            case "Receiver":
                // Temporary destination until receiver dashboard is ready.
                header("Location: ../index.php");
                exit;

            case "Admin":
                // Temporary destination until admin dashboard is ready.
                header("Location: ../index.php");
                exit;

            default:
                // Reject unexpected account roles.
                session_unset();
                session_destroy();

                header("Location: ../login.php?error=invalid");
                exit;
        }
    }
}

// Invalid credentials.
header("Location: ../login.php?error=invalid");
exit;

?>
