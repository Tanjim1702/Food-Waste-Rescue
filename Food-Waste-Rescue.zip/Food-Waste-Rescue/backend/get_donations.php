<?php

header("Content-Type: application/json; charset=UTF-8");

require "db.php";

// Retrieve available donations, including image paths
$sql = "SELECT
            id,
            food_name,
            category,
            quantity,
            donation_type,
            price,
            pickup_location,
            donor_name,
            image_path,
            status,
            created_at
        FROM donations
        WHERE status = 'Available'
        ORDER BY created_at DESC";

$result = $conn->query($sql);

if (!$result) {
    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Could not retrieve donations."
    ]);

    $conn->close();
    exit;
}

$donations = [];

while ($row = $result->fetch_assoc()) {
    $donations[] = $row;
}

echo json_encode([
    "success" => true,
    "donations" => $donations
]);

$conn->close();

?>