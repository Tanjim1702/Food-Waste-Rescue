
<?php

session_start();

require_once "db.php";

// Only accept POST requests
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../register.php");
    exit;
}


// Verify CSRF token
$submittedToken = $_POST["csrf_token"] ?? "";
$sessionToken = $_SESSION["csrf_token"] ?? "";

if (
    $sessionToken === "" ||
    !hash_equals($sessionToken, $submittedToken)
) {
    header("Location: ../register.php?error=csrf");
    exit;
}


// Collect form information
$name = trim($_POST["full_name"] ?? "");
$email = trim($_POST["email"] ?? "");
$phone = trim($_POST["phone"] ?? "");
$password = $_POST["password"] ?? "";
$roleInput = $_POST["role"] ?? "";
$organisationType = trim($_POST["organisation_type"] ?? "");


// Validate required fields
if (
    $name === "" ||
    $email === "" ||
    $phone === "" ||
    $password === ""
) {
    header("Location: ../register.php?error=empty");
    exit;
}


// Validate name length
if (strlen($name) > 100) {
    header("Location: ../register.php?error=failed");
    exit;
}


// Validate email
if (!filter_var($email, FILTER_VALIDATE_EMAIL) ||
    strlen($email) > 150) {

    header("Location: ../register.php?error=email");
    exit;
}


// Validate phone number
if (
    !preg_match('/^\+?[0-9][0-9\s()-]{6,18}$/', $phone)
) {
    header("Location: ../register.php?error=phone");
    exit;
}


// Validate password
if (
    strlen($password) < 8 ||
    strlen($password) > 72 ||
    !preg_match('/[A-Za-z]/', $password) ||
    !preg_match('/[0-9]/', $password)
) {
    header("Location: ../register.php?error=password");
    exit;
}


// Validate user role
$allowedRoles = [
    "donor" => "Donor",
    "receiver" => "Receiver"
];

if (!isset($allowedRoles[$roleInput])) {
    header("Location: ../register.php?error=role");
    exit;
}

$role = $allowedRoles[$roleInput];


// Validate organisation type
if (strlen($organisationType) > 60) {
    header("Location: ../register.php?error=failed");
    exit;
}

// Convert empty organisation type to NULL
if ($organisationType === "") {
    $organisationType = null;
}


// Hash password securely
$passwordHash = password_hash(
    $password,
    PASSWORD_DEFAULT
);


// Insert user into database
$stmt = $conn->prepare(
    "INSERT INTO users
    (name, email, phone, password_hash, role, organisation_type)
    VALUES (?, ?, ?, ?, ?, ?)"
);

if (!$stmt) {
    error_log("Registration prepare failed: " . $conn->error);
    header("Location: ../register.php?error=failed");
    exit;
}

$stmt->bind_param(
    "ssssss",
    $name,
    $email,
    $phone,
    $passwordHash,
    $role,
    $organisationType
);


// Execute query
if ($stmt->execute()) {

    // Generate a fresh token after successful registration
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));

    header("Location: ../register.php?success=1");
    exit;

} else {

    // Duplicate email
    if ($stmt->errno === 1062) {

        header("Location: ../register.php?error=duplicate");
        exit;

    }

    error_log("Registration failed: " . $stmt->error);

    header("Location: ../register.php?error=failed");
    exit;

}

?>
