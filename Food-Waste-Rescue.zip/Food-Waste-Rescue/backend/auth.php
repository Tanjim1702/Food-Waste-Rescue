
<?php

// Start the session if it has not already started.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Ensure the user is logged in.
 */
function require_login()
{
    if (
        !isset($_SESSION['user_id']) ||
        !isset($_SESSION['user_role']) ||
        !is_numeric($_SESSION['user_id'])
    ) {
        header("Location: ../login.php");
        exit;
    }
}

/**
 * Ensure the user has the required role.
 */
function require_role($required_role)
{
    require_login();

    if ($_SESSION['user_role'] !== $required_role) {
        http_response_code(403);
        exit("403 Forbidden: You do not have permission to access this page.");
    }
}
