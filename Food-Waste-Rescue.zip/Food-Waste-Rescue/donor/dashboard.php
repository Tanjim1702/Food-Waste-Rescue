
<?php

require_once "../backend/auth.php";
require_role("Donor");

require_once "../backend/db.php";

// Get the logged-in donor's ID and name.
$donor_id = (int) $_SESSION["user_id"];
$donor_name = $_SESSION["user_name"] ?? "Donor";

// Reusable function for retrieving dashboard counts.
function getDonorCount($conn, $sql, $donor_id)
{
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        error_log("Dashboard query preparation failed: " . $conn->error);
        return 0;
    }

    $stmt->bind_param("i", $donor_id);
    $stmt->execute();

    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    $count = (int) ($row["total"] ?? 0);

    $stmt->close();

    return $count;
}

// 1. Total food posts created by this donor.
$total_posts = getDonorCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM donations
     WHERE donor_id = ?",
    $donor_id
);

// 2. Donations that still have food available.
$available_posts = getDonorCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM donations
     WHERE donor_id = ?
     AND quantity_available > 0
     AND status IN ('Available', 'Partially Reserved')",
    $donor_id
);

// 3. Pending requests for this donor's donations.
$pending_requests = getDonorCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM collection_requests cr
     INNER JOIN donations d
        ON cr.donation_id = d.id
     WHERE d.donor_id = ?
     AND cr.status = 'Pending'",
    $donor_id
);

// 4. Completed collection requests for this donor.
$completed_collections = getDonorCount(
    $conn,
    "SELECT COUNT(*) AS total
     FROM collection_requests cr
     INNER JOIN donations d
        ON cr.donation_id = d.id
     WHERE d.donor_id = ?
     AND cr.status = 'Completed'",
    $donor_id
);

// 5. Retrieve the donor's five most recent food posts.
$recent_posts = [];

$stmt = $conn->prepare(
    "SELECT
        id,
        food_name,
        category,
        quantity,
        quantity_available,
        donation_type,
        price,
        status,
        image_path,
        created_at
     FROM donations
     WHERE donor_id = ?
     ORDER BY created_at DESC
     LIMIT 5"
);

if ($stmt) {
    $stmt->bind_param("i", $donor_id);
    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $recent_posts[] = $row;
    }

    $stmt->close();
} else {
    error_log("Recent posts query failed: " . $conn->error);
}

// 6. Retrieve the five most recent requests for this donor.
$recent_requests = [];

$stmt = $conn->prepare(
    "SELECT
        cr.id,
        cr.quantity_requested,
        cr.status,
        cr.requested_at,
        d.food_name,
        u.name AS receiver_name
     FROM collection_requests cr
     INNER JOIN donations d
        ON cr.donation_id = d.id
     INNER JOIN users u
        ON cr.receiver_id = u.id
     WHERE d.donor_id = ?
     ORDER BY cr.requested_at DESC
     LIMIT 5"
);

if ($stmt) {
    $stmt->bind_param("i", $donor_id);
    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $recent_requests[] = $row;
    }

    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Donor Dashboard | Food Waste Rescue</title>

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Dashboard CSS -->
    <link rel="stylesheet" href="../css/donor-dashboard.css">
</head>

<body>

<div class="dashboard-container">

    <!-- ================= SIDEBAR ================= -->
    <aside class="sidebar">

        <a href="../index.php" class="brand">
            <img src="../hero-images/leaf-logo(2).png"
                 alt="Food Waste Rescue Logo">

            <span class="brand-name">
                Food Waste<br>
                <strong>Rescue</strong>
            </span>
        </a>

        <div class="sidebar-label">DONOR MENU</div>

        <nav class="sidebar-menu">

            <a href="dashboard.php" class="menu-link active">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>

            <a href="my-food-posts.php" class="menu-link">
                <i class="bi bi-egg-fried"></i>
                <span>My Food Posts</span>
            </a>

            <a href="requests.php" class="menu-link">
                <i class="bi bi-inbox"></i>
                <span>Requests</span>
            </a>

            <a href="profile.php" class="menu-link">
                <i class="bi bi-person-circle"></i>
                <span>Profile</span>
            </a>

        </nav>

        <div class="sidebar-bottom">
            <div class="sidebar-note">
                <i class="bi bi-heart-fill"></i>
                <p>
                    Every meal saved is a step
                    towards a world without food waste.
                </p>
            </div>

            <a href="../logout.php" class="logout-link">
                <i class="bi bi-box-arrow-right"></i>
                <span>Logout</span>
            </a>
        </div>

    </aside>


    <!-- ================= MAIN CONTENT ================= -->
    <main class="main-content">

        <!-- TOP HEADER -->
        <header class="top-header">

            <div class="mobile-brand">
                <img src="../hero-images/leaf-logo.png"
                     alt="Food Waste Rescue">
                <span>Food Waste Rescue</span>
            </div>

            <div class="header-right">

                <button class="notification-button" type="button"
                        aria-label="Notifications">
                    <i class="bi bi-bell"></i>
                </button>

                <div class="user-info">

                    <div class="user-icon">
                        <i class="bi bi-person-fill"></i>
                    </div>

                    <div class="user-details">
                        <strong>
                            <?= htmlspecialchars($donor_name, ENT_QUOTES, 'UTF-8') ?>
                                
                            </strong>
                            <span>Donor Account</span>
                    </div>

                    <i class="bi bi-chevron-down user-chevron"></i>

                </div>

            </div>

        </header>


        <!-- DASHBOARD CONTENT -->
        <div class="content-wrapper">

            <!-- PAGE TITLE -->
            <section class="welcome-section">

                <div>
                    <p class="welcome-label">DONOR WORKSPACE</p>
                    <h1>Dashboard</h1>
                    <p class="welcome-description">
                        Manage your food donations and help reduce food waste.
                    </p>
                </div>

                <a href="../donate.php" class="add-food-button">
                    <i class="bi bi-plus-lg"></i>
                    Add Food
                </a>

            </section>


            <!-- SUMMARY CARDS -->
            <section class="summary-grid">

                <article class="summary-card">

                    <div class="summary-info">
                        <p>Total Food Posts</p>
                        <h2><?= number_format($total_posts) ?></h2>
                        <span>All your donations</span>
                    </div>

                    <div class="summary-icon green-icon">
                        <i class="bi bi-basket2"></i>
                    </div>

                </article>


                <article class="summary-card">

                    <div class="summary-info">
                        <p>Available Food</p>
                        <h2><?= number_format($available_posts) ?></h2>
                        <span>Ready for collection</span>
                    </div>

                    <div class="summary-icon yellow-icon">
                        <i class="bi bi-box-seam"></i>
                    </div>

                </article>


                <article class="summary-card">

                    <div class="summary-info">
                        <p>Pending Requests</p>
                        <h2><?= number_format($pending_requests) ?></h2>
                        <span>Awaiting your response</span>
                    </div>

                    <div class="summary-icon orange-icon">
                        <i class="bi bi-clock-history"></i>
                    </div>

                </article>


                <article class="summary-card">

                    <div class="summary-info">
                        <p>Completed Collections</p>
                        <h2><?= number_format($completed_collections) ?></h2>
                        <span>Successfully collected</span>
                    </div>

                    <div class="summary-icon blue-icon">
                        <i class="bi bi-check2-circle"></i>
                    </div>

                </article>

            </section>


            
<!-- MY FOOD POSTS SECTION -->
<section class="dashboard-section" id="food-posts">

    <div class="section-heading">
        <div>
            <h2>My Food Posts</h2>
            <p>Manage the food you have shared.</p>
        </div>

        <a href="my-food-posts.php" class="view-all-link">
            View All
            <i class="bi bi-arrow-right"></i>
        </a>
    </div>

    <?php if (!empty($recent_posts)): ?>

        <div class="recent-post-list">

            <?php foreach ($recent_posts as $post): ?>

                <article class="recent-post-card">

                    <div class="recent-post-image">

        <?php if (!empty($post["image_path"])): ?>

            <img
                src="../<?= htmlspecialchars(
                    $post["image_path"],
                    ENT_QUOTES,
                    "UTF-8"
                ) ?>"
                alt="<?= htmlspecialchars(
                    $post["food_name"],
                    ENT_QUOTES,
                    "UTF-8"
                ) ?>"
            >

        <?php else: ?>

            <div class="no-post-image">
                <i class="bi bi-image"></i>
            </div>

        <?php endif; ?>

    </div>

                    <div class="recent-post-info">

                        <h3>
                            <?= htmlspecialchars(
                                $post["food_name"],
                                ENT_QUOTES,
                                "UTF-8"
                            ) ?>
                        </h3>

                        <p class="recent-post-category">
                            <?= htmlspecialchars(
                                ucfirst($post["category"]),
                                ENT_QUOTES,
                                "UTF-8"
                            ) ?>
                        </p>

                        <div class="recent-post-details">

                            <span>
                                <i class="bi bi-box-seam"></i>
                                <?= (int) $post["quantity_available"] ?>
                                available /
                                <?= (int) $post["quantity"] ?>
                                total
                            </span>

                            <span>
                                <i class="bi bi-calendar3"></i>
                                <?= date(
                                    "M j, Y",
                                    strtotime($post["created_at"])
                                ) ?>
                            </span>

                        </div>

                        <?php if ($post["donation_type"] === "Paid"): ?>
                            <p class="recent-post-price">
                                Price: ৳<?= number_format(
                                    (float) $post["price"],
                                    2
                                ) ?>
                            </p>
                        <?php else: ?>
                            <p class="recent-post-price">Free donation</p>
                        <?php endif; ?>

                    </div>

                    <div class="recent-post-actions">

                        <span class="status-badge status-<?= strtolower(
                            str_replace(" ", "-", $post["status"])
                        ) ?>">
                            <?= htmlspecialchars(
                                $post["status"],
                                ENT_QUOTES,
                                "UTF-8"
                            ) ?>
                        </span>

                        <a href="my-food-posts.php"
                           class="recent-post-view">
                            View
                        </a>

                    </div>

                </article>

            <?php endforeach; ?>

        </div>

    <?php else: ?>

        <!-- Empty State -->
        <div class="empty-state">

            <div class="empty-icon">
                <i class="bi bi-basket3"></i>
            </div>

            <h3>No Food Posts Yet</h3>

            <p>
                Your food donations will appear here after
                you add them through the donation page.
            </p>

            <a href="../donate.php" class="empty-state-button">
                <i class="bi bi-plus-lg"></i>
                Add Your First Food
            </a>

        </div>

    <?php endif; ?>

</section>

            
<!-- RECENT REQUESTS SECTION -->
<section class="dashboard-section requests-section">

    <div class="section-heading">

        <div>
            <h2>Recent Requests</h2>
            <p>Keep track of requests for your food donations.</p>
        </div>

        <a href="requests.php" class="view-all-link">
            View All
            <i class="bi bi-arrow-right"></i>
        </a>

    </div>

    <?php if (!empty($recent_requests)): ?>

        <div class="recent-request-list">

            <?php foreach ($recent_requests as $request): ?>

                <article class="recent-request-card">

                    <div class="request-icon">
                        <i class="bi bi-inbox"></i>
                    </div>

                    <div class="request-info">

                        <h3>
                            <?= htmlspecialchars(
                                $request["food_name"],
                                ENT_QUOTES,
                                "UTF-8"
                            ) ?>
                        </h3>

                        <p>
                            Requested by:

                            <?= htmlspecialchars(
                                $request["receiver_name"],
                                ENT_QUOTES,
                                "UTF-8"
                            ) ?>
                        </p>

                        <div class="request-meta">

                            <span>
                                Quantity:
                                <?= (int) $request["quantity_requested"] ?>
                            </span>

                            <span>
                                <?= date(
                                    "M j, Y",
                                    strtotime($request["requested_at"])
                                ) ?>
                            </span>

                        </div>

                    </div>

                    <div class="request-status">

                        <span class="status-badge status-<?= strtolower(
                            $request["status"]
                        ) ?>">
                            <?= htmlspecialchars(
                                $request["status"],
                                ENT_QUOTES,
                                "UTF-8"
                            ) ?>
                        </span>

                    </div>

                </article>

            <?php endforeach; ?>

        </div>

    <?php else: ?>

        <!-- Empty Requests State -->
        <div class="empty-requests">

            <i class="bi bi-inbox"></i>

            <div>
                <h3>No Requests Yet</h3>

                <p>
                    Collection requests will appear here
                    when receivers request your food.
                </p>
            </div>

        </div>

    <?php endif; ?>

</section>

            <!-- FOOTER -->
            <footer class="dashboard-footer">

                <p>
                    Food Waste Rescue &copy; 2026.
                    Together, let's reduce food waste.
                </p>

                <div class="footer-links">
                    <a href="../how-it-works.php">How It Works</a>
                    <a href="../about.php">About Us</a>
                </div>

            </footer>

        </div>

    </main>

</div>

</body>
</html>
