
<?php
require_once "../backend/auth.php";
require_role("Donor");
require_once "../backend/db.php";

$donor_id = (int) $_SESSION["user_id"];
$donor_name = $_SESSION["user_name"] ?? "Donor";

// Validate the selected status filter.
$allowed_statuses = [
    "Available",
    "Partially Reserved",
    "Reserved",
    "Collected"
];

$selected_status = $_GET["status"] ?? "All";

if (
    $selected_status !== "All" &&
    !in_array($selected_status, $allowed_statuses, true)
) {
    $selected_status = "All";
}

// Validate the sorting option.
$sort = $_GET["sort"] ?? "newest";

if (!in_array($sort, ["newest", "oldest"], true)) {
    $sort = "newest";
}

$order_by = ($sort === "oldest")
    ? "ASC"
    : "DESC";

// Fetch only this donor's food posts.
$sql = "SELECT
            id,
            food_name,
            category,
            quantity,
            quantity_available,
            donation_type,
            price,
            pickup_location,
            status,
            created_at,
            image_path
        FROM donations
        WHERE donor_id = ?";

if ($selected_status !== "All") {
    $sql .= " AND status = ?";
}

$sql .= " ORDER BY created_at " . $order_by;

$stmt = $conn->prepare($sql);

if (!$stmt) {
    error_log("My Food Posts query failed: " . $conn->error);
    die("Unable to load your food posts. Please try again later.");
}

if ($selected_status === "All") {
    $stmt->bind_param("i", $donor_id);
} else {
    $stmt->bind_param("is", $donor_id, $selected_status);
}

$stmt->execute();

$result = $stmt->get_result();

$food_posts = [];

while ($row = $result->fetch_assoc()) {
    $food_posts[] = $row;
}

$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Food Posts | Food Waste Rescue</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- My Food Posts CSS -->
    <link rel="stylesheet" href="../css/donor-food-posts.css">
</head>

<body>

<div class="dashboard-container">

    <!-- ================= SIDEBAR ================= -->
    <aside class="sidebar">

        <a href="../index.php" class="brand">
            <img src="../hero-images/leaf-logo(2).png"
                 alt="Food Waste Rescue Logo">

            <span class="brand-name">
                Food Waste<br>
                <strong>Rescue</strong>
            </span>
        </a>

        <div class="sidebar-label">DONOR MENU</div>

        <nav class="sidebar-menu">

            <a href="dashboard.php" class="menu-link">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>

            <a href="my-food-posts.php" class="menu-link active">
                <i class="bi bi-egg-fried"></i>
                <span>My Food Posts</span>
            </a>

            <a href="requests.php" class="menu-link">
                <i class="bi bi-inbox"></i>
                <span>Requests</span>
            </a>

            <a href="profile.php" class="menu-link">
                <i class="bi bi-person-circle"></i>
                <span>Profile</span>
            </a>

        </nav>

        <div class="sidebar-bottom">

            <div class="sidebar-note">
                <i class="bi bi-heart-fill"></i>
                <p>
                    Every meal saved is a step
                    towards a world without food waste.
                </p>
            </div>

            <a href="../logout.php" class="logout-link">
                <i class="bi bi-box-arrow-right"></i>
                <span>Logout</span>
            </a>

        </div>

    </aside>


    <!-- ================= MAIN CONTENT ================= -->
    <main class="main-content">

        <!-- TOP HEADER -->
        <header class="top-header">

            <div class="mobile-brand">
                <img src="../hero-images/leaf-logo.png"
                     alt="Food Waste Rescue">
                <span>Food Waste Rescue</span>
            </div>

            <div class="header-right">

                <button class="notification-button"
                        type="button"
                        aria-label="Notifications">
                    <i class="bi bi-bell"></i>
                </button>

                <div class="user-info">

                    <div class="user-icon">
                        <i class="bi bi-person-fill"></i>
                    </div>
                    <div class="user-details">
                        <strong>
                            <?= htmlspecialchars($donor_name, ENT_QUOTES, "UTF-8") ?>        
                        </strong>
                        <span>Donor Account</span>
                    </div>
                    <i class="bi bi-chevron-down user-chevron"></i>

                </div>

            </div>

        </header>


        <!-- PAGE CONTENT -->
        <div class="content-wrapper">

            <!-- PAGE HEADING -->
            <section class="page-heading">

                <div class="heading-text">
                    <p class="page-label">DONOR WORKSPACE</p>

                    <h1>My Food Posts</h1>

                    <p class="page-description">
                        Manage and keep track of the food donations
                        you have shared with your community.
                    </p>
                </div>

                <a href="../donate.php" class="add-food-button">
                    <i class="bi bi-plus-lg"></i>
                    Add Food
                </a>

            </section>


            <!-- FOOD POST OVERVIEW -->
            <section class="food-overview">

                <div class="overview-heading">
                    <div>
                        <h2>Your Donations</h2>
                        <p>
                            All the food donations you have posted.
                        </p>
                    </div>
                </div>


                <!-- FILTER BAR -->
<div class="filter-bar">

    <div class="filter-options">

        <?php
        $filters = [
            "All" => "All Posts",
            "Available" => "Available",
            "Partially Reserved" => "Partially Reserved",
            "Reserved" => "Reserved",
            "Collected" => "Collected"
        ];
        ?>

        <?php foreach ($filters as $value => $label): ?>

            <a
                href="?status=<?= urlencode($value) ?>&sort=<?= urlencode($sort) ?>"
                class="filter-button <?= $selected_status === $value ? 'active' : '' ?>"
            >
                <?= htmlspecialchars($label, ENT_QUOTES, "UTF-8") ?>
            </a>

        <?php endforeach; ?>

    </div>

    <form method="GET" class="sort-option">

        <input
            type="hidden"
            name="status"
            value="<?= htmlspecialchars($selected_status, ENT_QUOTES, "UTF-8") ?>"
        >

        <i class="bi bi-sort-down"></i>

        <select name="sort" onchange="this.form.submit()">

            <option value="newest" <?= $sort === "newest" ? "selected" : "" ?>>
                Newest First
            </option>

            <option value="oldest" <?= $sort === "oldest" ? "selected" : "" ?>>
                Oldest First
            </option>

        </select>

    </form>

</div>
               <!-- FOOD POSTS CONTAINER -->
<div class="food-posts-container">

    <?php if (count($food_posts) > 0): ?>

        <div class="food-posts-grid">

            <?php foreach ($food_posts as $post): ?>

                <article class="food-post-card">

                    <!-- FOOD IMAGE -->
                    <div class="food-post-image">

                        <?php if (!empty($post["image_path"])): ?>

                            <img
                                src="../<?= htmlspecialchars($post["image_path"], ENT_QUOTES, "UTF-8") ?>"
                                alt="<?= htmlspecialchars($post["food_name"], ENT_QUOTES, "UTF-8") ?>"
                            >

                        <?php else: ?>

                            <div class="food-image-placeholder">
                                <i class="bi bi-image"></i>
                            </div>

                        <?php endif; ?>

                        <span class="post-status status-<?= strtolower(str_replace(" ", "-", $post["status"])) ?>">
                            <?= htmlspecialchars($post["status"], ENT_QUOTES, "UTF-8") ?>
                        </span>

                    </div>

                    <!-- FOOD DETAILS -->
                    <div class="food-post-details">

                        <div class="food-post-heading">

                            <h3>
                                <?= htmlspecialchars($post["food_name"], ENT_QUOTES, "UTF-8") ?>
                            </h3>

                            <span class="food-category">
                                <?= htmlspecialchars(ucfirst($post["category"]), ENT_QUOTES, "UTF-8") ?>
                            </span>

                        </div>

                        <div class="food-post-info">

                            <p>
                                <i class="bi bi-box-seam"></i>
                                Original quantity:
                                <strong>
                                    <?= (int) $post["quantity"] ?>
                                </strong>
                            </p>

                            <p>
                                <i class="bi bi-box2"></i>
                                Available quantity:
                                <strong>
                                    <?= (int) $post["quantity_available"] ?>
                                </strong>
                            </p>

                            <p>
                                <i class="bi bi-geo-alt"></i>
                                <?= htmlspecialchars($post["pickup_location"], ENT_QUOTES, "UTF-8") ?>
                            </p>

                            <p>
                                <i class="bi bi-calendar3"></i>
                                <?= date("d M Y", strtotime($post["created_at"])) ?>
                            </p>

                        </div>

                        <div class="food-post-footer">

                            <span class="donation-price">

                                <?php if ($post["donation_type"] === "Free"): ?>

                                    Free Donation

                                <?php else: ?>

                                    ৳<?= number_format((float) $post["price"], 2) ?>

                                <?php endif; ?>

                            </span>

                            <span class="post-id">
                                Post #<?= (int) $post["id"] ?>
                            </span>

                        </div>
                        <!-- POST ACTIONS -->
<div class="food-post-actions">

    <a
        href="edit-food-post.php?id=<?= (int) $post['id'] ?>"
        class="edit-post-button"
    >
        <i class="bi bi-pencil-square"></i>
        Edit
    </a>

    <button
        type="button"
        class="delete-post-button"
        disabled
        title="Delete functionality will be enabled after backend implementation"
    >
        <i class="bi bi-trash"></i>
        Delete
    </button>

</div>

                    </div>

                </article>

            <?php endforeach; ?>

        </div>

    <?php else: ?>

        <!-- EMPTY STATE -->
        <div class="empty-state">

            <div class="empty-icon">
                <i class="bi bi-basket3"></i>
            </div>

            <h3>
                <?= $selected_status === "All"
                    ? "No Food Posts Yet"
                    : "No " . htmlspecialchars($selected_status, ENT_QUOTES, "UTF-8") . " Posts" ?>
            </h3>

            <p>

                <?php if ($selected_status === "All"): ?>

                    You haven't shared any food donations yet.
                    Add your first donation and help someone
                    in your community.

                <?php else: ?>

                    You don't have any food posts with this status.

                <?php endif; ?>

            </p>

            <a href="../donate.php" class="empty-state-button">
                <i class="bi bi-plus-lg"></i>
                Add Food
            </a>

        </div>

    <?php endif; ?>

</div>
                    
            </section>


            <!-- INFORMATION NOTE -->
            <div class="information-note">

                <i class="bi bi-info-circle"></i>

                <p>
                    Food posts you create through the Add Food page
                    will appear here. You can manage their details
                    and availability from this section.
                </p>

            </div>


            <!-- FOOTER -->
            <footer class="dashboard-footer">

                <p>
                    Food Waste Rescue &copy; 2026.
                    Together, let's reduce food waste.
                </p>

                <div class="footer-links">
                    <a href="../how-it-works.php">How It Works</a>
                    <a href="../about.php">About Us</a>
                </div>

            </footer>

        </div>

    </main>

</div>

</body>
</html>
