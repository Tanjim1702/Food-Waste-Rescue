
<?php
require_once "../backend/auth.php";
require_role("Donor");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Profile | Food Waste Rescue</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Profile CSS -->
    <link rel="stylesheet" href="../css/donor-profile.css">
</head>

<body>

<div class="dashboard-container">

    <!-- ================= SIDEBAR ================= -->
    <aside class="sidebar">

        <a href="../index.php" class="brand">
            <img src="../hero-images/leaf-logo(2).png"
                 alt="Food Waste Rescue Logo">

            <span class="brand-name">
                Food Waste<br>
                <strong>Rescue</strong>
            </span>
        </a>

        <div class="sidebar-label">DONOR MENU</div>

        <nav class="sidebar-menu">

            <a href="dashboard.php" class="menu-link">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>

            <a href="my-food-posts.php" class="menu-link">
                <i class="bi bi-egg-fried"></i>
                <span>My Food Posts</span>
            </a>

            <a href="requests.php" class="menu-link">
                <i class="bi bi-inbox"></i>
                <span>Requests</span>
            </a>

            <a href="profile.php" class="menu-link active">
                <i class="bi bi-person-circle"></i>
                <span>Profile</span>
            </a>

        </nav>

        <div class="sidebar-bottom">

            <div class="sidebar-note">
                <i class="bi bi-heart-fill"></i>
                <p>
                    Every meal saved is a step
                    towards a world without food waste.
                </p>
            </div>

            <a href="../logout.php" class="logout-link">
                <i class="bi bi-box-arrow-right"></i>
                <span>Logout</span>
            </a>

        </div>

    </aside>


    <!-- ================= MAIN CONTENT ================= -->
    <main class="main-content">

        <!-- TOP HEADER -->
        <header class="top-header">

            <div class="mobile-brand">
                <img src="../hero-images/leaf-logo.png"
                     alt="Food Waste Rescue">
                <span>Food Waste Rescue</span>
            </div>

            <div class="header-right">

                <button class="notification-button"
                        type="button"
                        aria-label="Notifications">
                    <i class="bi bi-bell"></i>
                </button>

                <div class="user-info">

                    <div class="user-icon">
                        <i class="bi bi-person-fill"></i>
                    </div>

                    <div class="user-details">
                        <strong>Donor Name</strong>
                        <span>Donor Account</span>
                    </div>

                    <i class="bi bi-chevron-down user-chevron"></i>

                </div>

            </div>

        </header>


        <!-- PAGE CONTENT -->
        <div class="content-wrapper">

            <!-- PAGE HEADING -->
            <section class="page-heading">

                <div>
                    <p class="page-label">DONOR WORKSPACE</p>

                    <h1>My Profile</h1>

                    <p class="page-description">
                        Manage your personal information
                        and account details.
                    </p>
                </div>

            </section>


            <!-- PROFILE OVERVIEW -->
            <section class="profile-overview">

                <div class="profile-avatar">
                    <i class="bi bi-person-fill"></i>
                </div>

                <div class="profile-overview-info">

                    <h2>Donor Name</h2>

                    <p>Donor Account</p>

                    <span class="account-badge">
                        <i class="bi bi-patch-check-fill"></i>
                        Registered Donor
                    </span>

                </div>

                <div class="profile-overview-icon">
                    <i class="bi bi-person-vcard"></i>
                </div>

            </section>


            <!-- PERSONAL INFORMATION -->
            <section class="profile-section">

                <div class="section-heading">

                    <div class="section-icon">
                        <i class="bi bi-person"></i>
                    </div>

                    <div>
                        <h2>Personal Information</h2>
                        <p>
                            Your basic account information.
                        </p>
                    </div>

                </div>


                <form class="profile-form">

                    <div class="form-grid">

                        <div class="form-group full-width">

                            <label for="fullName">Full Name</label>

                            <input
                                type="text"
                                id="fullName"
                                name="name"
                                placeholder="Enter your full name"
                                autocomplete="name"
                            >

                        </div>


                        <div class="form-group">

                            <label for="email">Email Address</label>

                            <div class="input-with-icon">
                                <i class="bi bi-envelope"></i>

                                <input
                                    type="email"
                                    id="email"
                                    name="email"
                                    placeholder="Enter your email"
                                    autocomplete="email"
                                >
                            </div>

                        </div>


                        <div class="form-group">

                            <label for="phone">Phone Number</label>

                            <div class="input-with-icon">
                                <i class="bi bi-telephone"></i>

                                <input
                                    type="tel"
                                    id="phone"
                                    name="phone"
                                    placeholder="Enter your phone number"
                                    autocomplete="tel"
                                >
                            </div>

                        </div>

                    </div>


                    <div class="form-actions">

                        <button type="reset" class="cancel-button">
                            Cancel
                        </button>

                        <button type="button" class="save-button">
                            <i class="bi bi-check-lg"></i>
                            Save Changes
                        </button>

                    </div>

                </form>

            </section>


            <!-- ORGANISATION INFORMATION -->
            <section class="profile-section">

                <div class="section-heading">

                    <div class="section-icon">
                        <i class="bi bi-building"></i>
                    </div>

                    <div>
                        <h2>Organisation Information</h2>
                        <p>
                            Details about your donor organisation.
                        </p>
                    </div>

                </div>


                <div class="form-grid">

                    <div class="form-group">

                        <label for="organisationType">
                            Organisation Type
                        </label>

                        <select id="organisationType"
                                name="organisation_type">

                            <option value="" selected disabled>
                                Select organisation type
                            </option>

                            <option value="Owner">Owner</option>
                            <option value="Restaurant">Restaurant</option>
                            <option value="Bakery">Bakery</option>
                            <option value="Grocery Store">Grocery Store</option>
                            <option value="Other">Other</option>

                        </select>

                    </div>


                    <div class="form-group">

                        <label for="accountRole">Account Role</label>

                        <input
                            type="text"
                            id="accountRole"
                            value="Donor"
                            readonly
                        >

                    </div>

                </div>

                <div class="form-actions">

                    <button type="button" class="save-button">
                        <i class="bi bi-check-lg"></i>
                        Save Organisation Details
                    </button>

                </div>

            </section>


            <!-- ACCOUNT SECURITY -->
            <section class="profile-section security-section">

                <div class="section-heading">

                    <div class="section-icon">
                        <i class="bi bi-shield-lock"></i>
                    </div>

                    <div>
                        <h2>Account Security</h2>
                        <p>
                            Keep your account information secure.
                        </p>
                    </div>

                </div>


                <div class="security-item">

                    <div class="security-info">

                        <div class="security-item-icon">
                            <i class="bi bi-key"></i>
                        </div>

                        <div>
                            <h3>Password</h3>
                            <p>
                                Change your password to protect your account.
                            </p>
                        </div>

                    </div>

                    <button type="button" class="password-button">
                        Change Password
                        <i class="bi bi-arrow-right"></i>
                    </button>

                </div>

            </section>


            <!-- INFORMATION NOTE -->
            <div class="information-note">

                <i class="bi bi-info-circle"></i>

                <p>
                    Keep your contact information updated so
                    receivers can communicate with you about
                    their food collection requests.
                </p>

            </div>


            <!-- FOOTER -->
            <footer class="dashboard-footer">

                <p>
                    Food Waste Rescue &copy; 2026.
                    Together, let's reduce food waste.
                </p>

                <div class="footer-links">
                    <a href="../how-it-works.php">How It Works</a>
                    <a href="../about.php">About Us</a>
                </div>

            </footer>

        </div>

    </main>

</div>

</body>
</html>
