
<?php
require_once "../backend/auth.php";
require_role("Donor");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Requests | Food Waste Rescue</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Requests CSS -->
    <link rel="stylesheet" href="../css/donor-requests.css">
</head>

<body>

<div class="dashboard-container">

    <!-- ================= SIDEBAR ================= -->
    <aside class="sidebar">

        <a href="../index.php" class="brand">
            <img src="../hero-images/leaf-logo(2).png"
                 alt="Food Waste Rescue Logo">

            <span class="brand-name">
                Food Waste<br>
                <strong>Rescue</strong>
            </span>
        </a>

        <div class="sidebar-label">DONOR MENU</div>

        <nav class="sidebar-menu">

            <a href="dashboard.php" class="menu-link">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>

            <a href="my-food-posts.php" class="menu-link">
                <i class="bi bi-egg-fried"></i>
                <span>My Food Posts</span>
            </a>

            <a href="requests.php" class="menu-link active">
                <i class="bi bi-inbox"></i>
                <span>Requests</span>
            </a>

            <a href="profile.php" class="menu-link">
                <i class="bi bi-person-circle"></i>
                <span>Profile</span>
            </a>

        </nav>

        <div class="sidebar-bottom">

            <div class="sidebar-note">
                <i class="bi bi-heart-fill"></i>
                <p>
                    Every meal saved is a step
                    towards a world without food waste.
                </p>
            </div>

            <a href="../logout.php" class="logout-link">
                <i class="bi bi-box-arrow-right"></i>
                <span>Logout</span>
            </a>

        </div>

    </aside>


    <!-- ================= MAIN CONTENT ================= -->
    <main class="main-content">

        <!-- TOP HEADER -->
        <header class="top-header">

            <div class="mobile-brand">
                <img src="../hero-images/leaf-logo.png"
                     alt="Food Waste Rescue">
                <span>Food Waste Rescue</span>
            </div>

            <div class="header-right">

                <button class="notification-button"
                        type="button"
                        aria-label="Notifications">
                    <i class="bi bi-bell"></i>
                </button>

                <div class="user-info">

                    <div class="user-icon">
                        <i class="bi bi-person-fill"></i>
                    </div>

                    <div class="user-details">
                        <strong>Donor Name</strong>
                        <span>Donor Account</span>
                    </div>

                    <i class="bi bi-chevron-down user-chevron"></i>

                </div>

            </div>

        </header>


        <!-- PAGE CONTENT -->
        <div class="content-wrapper">

            <!-- PAGE HEADING -->
            <section class="page-heading">

                <div class="heading-text">

                    <p class="page-label">DONOR WORKSPACE</p>

                    <h1>Collection Requests</h1>

                    <p class="page-description">
                        Review and manage requests from people
                        interested in collecting your donated food.
                    </p>

                </div>

            </section>


            <!-- REQUEST SUMMARY -->
            <section class="request-summary">

                <article class="summary-card">

                    <div class="summary-info">
                        <p>Total Requests</p>
                        <h2>—</h2>
                        <span>All received requests</span>
                    </div>

                    <div class="summary-icon green-icon">
                        <i class="bi bi-inbox"></i>
                    </div>

                </article>


                <article class="summary-card">

                    <div class="summary-info">
                        <p>Pending</p>
                        <h2>—</h2>
                        <span>Awaiting your response</span>
                    </div>

                    <div class="summary-icon yellow-icon">
                        <i class="bi bi-clock-history"></i>
                    </div>

                </article>


                <article class="summary-card">

                    <div class="summary-info">
                        <p>Approved</p>
                        <h2>—</h2>
                        <span>Approved for collection</span>
                    </div>

                    <div class="summary-icon blue-icon">
                        <i class="bi bi-check-circle"></i>
                    </div>

                </article>


                <article class="summary-card">

                    <div class="summary-info">
                        <p>Completed</p>
                        <h2>—</h2>
                        <span>Successfully collected</span>
                    </div>

                    <div class="summary-icon purple-icon">
                        <i class="bi bi-check2-all"></i>
                    </div>

                </article>

            </section>


            <!-- REQUEST MANAGEMENT -->
            <section class="requests-section">

                <div class="section-heading">

                    <div>
                        <h2>Received Requests</h2>
                        <p>
                            View and manage collection requests
                            for your food donations.
                        </p>
                    </div>

                </div>


                <!-- FILTER BAR: FRONTEND DESIGN ONLY -->
                <div class="filter-bar">

                    <div class="filter-options">

                        <button type="button"
                                class="filter-button active">
                            All Requests
                        </button>

                        <button type="button"
                                class="filter-button">
                            Pending
                        </button>

                        <button type="button"
                                class="filter-button">
                            Approved
                        </button>

                        <button type="button"
                                class="filter-button">
                            Rejected
                        </button>

                        <button type="button"
                                class="filter-button">
                            Completed
                        </button>

                    </div>

                    <div class="sort-option">
                        <i class="bi bi-sort-down"></i>
                        <span>Newest First</span>
                    </div>

                </div>


                <!-- REQUEST LIST -->
                <div class="requests-container">

                    <!-- EMPTY STATE -->
                    <div class="empty-state">

                        <div class="empty-icon">
                            <i class="bi bi-inbox"></i>
                        </div>

                        <h3>No Collection Requests Yet</h3>

                        <p>
                            When someone requests to collect
                            your donated food, their request
                            details will appear here.
                        </p>

                        <a href="my-food-posts.php"
                           class="empty-state-button">
                            <i class="bi bi-egg-fried"></i>
                            View My Food Posts
                        </a>

                    </div>

                </div>

            </section>


            <!-- REQUEST GUIDELINES -->
            <section class="request-guidelines">

                <div class="guideline-icon">
                    <i class="bi bi-lightbulb"></i>
                </div>

                <div class="guideline-content">

                    <h3>Managing Collection Requests</h3>

                    <p>
                        Review the requested food and quantity
                        before approving a request. Make sure
                        sufficient food is available for collection.
                    </p>

                </div>

            </section>


            <!-- FOOTER -->
            <footer class="dashboard-footer">

                <p>
                    Food Waste Rescue &copy; 2026.
                    Together, let's reduce food waste.
                </p>

                <div class="footer-links">
                    <a href="../how-it-works.php">How It Works</a>
                    <a href="../about.php">About Us</a>
                </div>

            </footer>

        </div>

    </main>

</div>

</body>
</html>
