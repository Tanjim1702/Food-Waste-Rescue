
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Waste Rescue</title>

    <!-- Bootstrap CSS -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Our CSS file -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar navbar-expand-lg bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold text-success d-flex align-items-center"
   href="index.php">

    <img src="hero-images/leaf-logo.png"
         alt="Food Waste Rescue Logo"
         class="brand-logo">

    <span>Food Waste Rescue</span>

</a>
            <div class="ms-auto">
                <a href="login.php" class="btn btn-outline-success me-2">
                    Login
                </a>
                <a href="register.php" class="btn btn-outline-success">
                    Register
                </a>
            </div>
        </div>
    </nav>

    
<section class="hero">
    <div class="container">
        <div class="row align-items-center gx-5 gy-4">

            <div class="col-md-6">
                <h1>Good Food 
                Should Feed People
                Not Landfills
                </h1>

                <p>Rescue surplus food. Reduce waste. Help your community.</p>

                <a href="#food" class="btn btn-success btn-lg me-2">
                    Find Food
                </a>

                <a href="#donate" class="btn btn-outline-success btn-lg">
                    Donate Food
                </a>
            </div>

            <div class="col-md-6">
                <img
                    src="hero-images/hero-food.jpg"
                    alt="A bowl of fresh food"
                    class="hero-image img-fluid"
                >
            </div>

        </div>
    </div>
</section>


    <section id="about" class="container py-5 text-center">
        <h2>Making a Difference Together</h2>
        <p>We connect food donors with people who need food.</p>
    </section>


<!-- Statistics Section -->
<section class="stats-section py-5">
    <div class="container">
        <div class="row text-center g-4">

            <div class="col-6 col-md-3">
                <h3>320</h3>
                <p>Food Portions Rescued</p>
            </div>

            <div class="col-6 col-md-3">
                <h3>85</h3>
                <p>Donations Completed</p>
            </div>

            <div class="col-6 col-md-3">
                <h3>24</h3>
                <p>Active Donors</p>
            </div>

            <div class="col-6 col-md-3">
                <h3>320</h3>
                <p>Portions Saved From Waste</p>
            </div>

        </div>
    </div>
</section>

    
<section id="food" class="container py-5">
    <div class="text-center mb-4">
    <h2>Available Food</h2>
    <p>Discover food and give it a second chance.</p>

    <div class="row justify-content-center mt-4">
        <div class="col-md-6">
            <input
                type="text"
                id="foodSearch"
                class="form-control form-control-lg"
                placeholder="Search for vegetables, bread, meals..."
                aria-label="Search available food"
            >
        </div>
    </div>
</div>
<!-- Food Category Filters -->
<div class="d-flex justify-content-center flex-wrap gap-2 mt-4">

    <button class="btn btn-success category-btn active"
            data-category="all">
        All
    </button>

    <button class="btn btn-outline-success category-btn"
            data-category="vegetables">
        Vegetables
    </button>


<button type="button"
        class="btn btn-outline-success category-btn"
        data-category="fruits">
    Fruits
</button>


    <button class="btn btn-outline-success category-btn"
            data-category="bread">
        Bread
    </button>

    <button class="btn btn-outline-success category-btn"
            data-category="meals">
        Meals
    </button>

</div>

    <div class="row g-4">

        <!-- Food Card 1 -->
       <div class="col-md-4 food-item">
            <div class="card food-card h-100">
                <img
    src="images/vegetables.jpg"
    class="card-img-top"
    alt="Fresh vegetables"
>
                
                <div class="card-body">
                    <span class="badge bg-success mb-2">Free</span>
                    <h5 class="card-title">Fresh Vegetables</h5>
                    <p class="card-text">
                        Fresh surplus vegetables from a local grocery store.
                    </p>
                    <p class="text-muted">Donor: Green Grocery</p>
                    <button type="button"
        class="btn btn-success view-details-btn"
        data-food-name="Fresh Vegetables">
    View Details
</button>
                </div>
            </div>
        </div>

        <!-- Food Card 2 -->
       
        <div class="col-md-4 food-item">
            <div class="card food-card h-100">
               <img
    src="images/bread.jpg"
    class="card-img-top"
    alt="Fresh bread"
>
                
                <div class="card-body">
                    <span class="badge bg-warning text-dark mb-2">
                        ৳100
                    </span>
                    <h5 class="card-title">Fresh Bread</h5>
                    <p class="card-text">
                        Surplus bread available at a reduced price.
                    </p>
                    <p class="text-muted">Donor: Sunrise Bakery</p>
                    <button type="button"
        class="btn btn-success view-details-btn"
        data-food-name="Fresh Bread">
    View Details
</button>
                </div>
            </div>
        </div>

        <!-- Food Card 3 -->
        <div class="col-md-4 food-item">
            <div class="card food-card h-100">
                <img
    src="images/meals.jpg"
    class="card-img-top"
    alt="Prepared meals"
>   
                
                <div class="card-body">
                    <span class="badge bg-success mb-2">Free</span>
                    <h5 class="card-title">Surplus Meals</h5>
                    <p class="card-text">
                        Surplus meals available for community collection.
                    </p>
                    <p class="text-muted">Donor: Community Kitchen</p>
                    <button type="button" class="btn btn-success view-details-btn"
        data-food-name="Surplus Meals"
        data-bs-toggle="modal"
        data-bs-target="#foodDetailsModal">
    View Details
</button>
                </div>
            </div>
        </div>

    </div>
</section>


<!-- Food Details Modal -->
<div class="modal fade" id="foodDetailsModal" tabindex="-1"
     aria-labelledby="foodDetailsTitle" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="foodDetailsTitle">
                    Food Details
                </h5>

                <button type="button" class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <p><strong>Food:</strong> <span id="detailFoodName"></span></p>
                <p><strong>Description:</strong> <span id="detailDescription"></span></p>
                <p><strong>Quantity:</strong> <span id="detailQuantity"></span></p>
                <p><strong>Price:</strong> <span id="detailPrice"></span></p>
                <p><strong>Donor:</strong> <span id="detailDonor"></span></p>
                <p><strong>Pickup Location:</strong> <span id="detailLocation"></span></p>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary"
                        data-bs-dismiss="modal">
                    Close
                </button>
            </div>

        </div>
    </div>
</div>


    <footer id="donate" class="text-center py-4">
        <p class="mb-0">
            Food Waste Rescue · Saving food, supporting communities.
        </p>
    </footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/food-data.js"></script>
<script src="js/script.js"></script>
<script src="js/donate.js"></script>
</body>
</html> 
