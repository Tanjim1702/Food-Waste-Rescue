
const foodSearch = document.getElementById("foodSearch");
const foodItemsContainer = document.querySelector("#food .row.g-4");
const categoryButtons = document.querySelectorAll(".category-btn");
const foodDetailsModal = document.getElementById("foodDetailsModal");

function showFoodDetails(food) {
    document.getElementById("detailFoodName").textContent =
        food.foodName;

    document.getElementById("detailDescription").textContent =
        food.description || food.category || "Not provided";

    document.getElementById("detailQuantity").textContent =
        food.quantity ? food.quantity : "Not provided";

    document.getElementById("detailPrice").textContent =
        food.donationType === "Free"
            ? "Free"
            : food.donationType === "Paid"
                ? "৳" + Number(food.price).toFixed(2)
                : "Not provided";

    document.getElementById("detailDonor").textContent =
        food.donorName || "Not provided";

    document.getElementById("detailLocation").textContent =
        food.pickupLocation || "Not provided";

    const modal = bootstrap.Modal.getOrCreateInstance(foodDetailsModal);
    modal.show();
}

// Connect the original food cards to the details modal
document.querySelectorAll(".view-details-btn").forEach(function (button) {
    button.addEventListener("click", function () {
        const foodName = button.dataset.foodName;

        let foodDetails = {};

        if (foodName === "Fresh Vegetables") {
           foodDetails = {
    foodName: "Fresh Vegetables",
    description: "Fresh surplus vegetables from a local grocery store.",
    quantity: "5 kg",
    donationType: "Free",
    price: 0,
    donorName: "Green Grocery",
    pickupLocation: "Please contact the donor"
};
        } else if (foodName === "Fresh Bread") {
           foodDetails = {
    foodName: "Fresh Bread",
    description: "Surplus bread available at a reduced price.",
    quantity: "20 loaves",
    donationType: "Paid",
    price: 100,
    donorName: "Sunrise Bakery",
    pickupLocation: "Please contact the donor"
};
        } else if (foodName === "Surplus Meals") {
            foodDetails = {
    foodName: "Surplus Meals",
    description: "Surplus meals available for community collection.",
    quantity: "15 meal portions",
    donationType: "Free",
    price: 0,
    donorName: "Community Kitchen",
    pickupLocation: "Please contact the donor"
};
        } else {
            return;
        }

        showFoodDetails(foodDetails);
    });
});

let selectedCategory = "all";

// Give existing cards their categories
document.querySelectorAll(".food-item").forEach(function (item) {
    const title = item.querySelector(".card-title")
        .textContent.toLowerCase();

    if (title.includes("vegetable")) {
        item.dataset.category = "vegetables";
    } else if (title.includes("bread")) {
        item.dataset.category = "bread";
    } else if (title.includes("meal")) {
        item.dataset.category = "meals";
    } else {
        item.dataset.category = "other";
    }
});

// Create a card for a newly submitted donation
function createFoodCard(donation) {
    const column = document.createElement("div");
    column.className = "col-md-4 food-item";
    column.dataset.category = donation.category;

    const card = document.createElement("div");
card.className = "card food-card h-100";

// Display the uploaded food image
if (donation.imagePath) {
    const image = document.createElement("img");

    image.src = donation.imagePath;
    image.alt = donation.foodName;
    image.className = "card-img-top";

    image.style.height = "200px";
    image.style.objectFit = "cover";

    // Hide the image if the file cannot be loaded
    image.onerror = function () {
        image.style.display = "none";
    };

    card.appendChild(image);
}

const body = document.createElement("div");
body.className = "card-body";
    const badge = document.createElement("span");
    badge.className = donation.donationType === "Free"
        ? "badge bg-success mb-2"
        : "badge bg-warning text-dark mb-2";
    badge.textContent = donation.donationType;

    const title = document.createElement("h5");
    title.className = "card-title";
    title.textContent = donation.foodName;

    const description = document.createElement("p");
    description.className = "card-text";
    description.textContent =
        "Quantity: " + donation.quantity +
        " | Category: " + donation.category;

    const price = document.createElement("p");
price.className = "fw-bold";
price.textContent = donation.donationType === "Paid"
    ? "Price: ৳" + Number(donation.price).toFixed(2)
    : "Free";

    const donor = document.createElement("p");
    donor.className = "text-muted";
    donor.textContent = "Donor: " + donation.donorName;

    const location = document.createElement("p");
    location.className = "text-muted";
    location.textContent = "Pickup: " + donation.pickupLocation;

    const detailsButton = document.createElement("button");
detailsButton.type = "button";
detailsButton.className = "btn btn-success view-details-btn";
detailsButton.textContent = "View Details";

detailsButton.addEventListener("click", function () {
    showFoodDetails(donation);
});

body.append(
    badge,
    title,
    description,
    price,
    donor,
    location,
    detailsButton
);
    card.appendChild(body);
    column.appendChild(card);

    return column;
}


// Load donations from the MySQL database through PHP
async function displayDonations() {
    try {
        const response = await fetch("backend/get_donations.php");
        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error("Could not load donations.");
        }

        const donations = result.donations;

        donations.forEach(function (row) {
            // Avoid displaying the same donation twice
            if (
                foodItemsContainer.querySelector(
                    '[data-donation-id="' + row.id + '"]'
                )
            ) {
                return;
            }

            const donation = {
                id: row.id,
                foodName: row.food_name,
                category: row.category,
                quantity: row.quantity,
                donationType: row.donation_type,
                price: row.price,
                pickupLocation: row.pickup_location,
                donorName: row.donor_name,
                imagePath: row.image_path,
                status: row.status
            };

            const card = createFoodCard(donation);
            card.dataset.donationId = row.id;
            foodItemsContainer.prepend(card);
        });

        filterFood();

    } catch (error) {
        console.error("Error loading donations:", error);
    }
}

// Search and category filters work together


function filterFood() {
    const searchText = foodSearch.value.toLowerCase().trim();
    let visibleItems = 0;

    document.querySelectorAll(".food-item").forEach(function (item) {
        const details = item.textContent.toLowerCase();
        const category = item.dataset.category;

        const matchesSearch = details.includes(searchText);
        const matchesCategory =
            selectedCategory === "all" ||
            category === selectedCategory;

        if (matchesSearch && matchesCategory) {
            item.style.display = "";
            visibleItems++;
        } else {
            item.style.display = "none";
        }
    });

    let noResultsMessage = document.getElementById("noResultsMessage");

    if (visibleItems === 0) {
        if (!noResultsMessage) {
            noResultsMessage = document.createElement("p");
            noResultsMessage.id = "noResultsMessage";
            noResultsMessage.className = "text-center text-muted mt-4";
            noResultsMessage.textContent =
                "No food found. Try another search or category.";

            foodItemsContainer.appendChild(noResultsMessage);
        }
    } else if (noResultsMessage) {
        noResultsMessage.remove();
    }
}



// Search as the user types
foodSearch.addEventListener("input", filterFood);

// Handle category button clicks
categoryButtons.forEach(function (button) {
    button.addEventListener("click", function () {
        selectedCategory = button.dataset.category;

        categoryButtons.forEach(function (btn) {
            btn.classList.remove("btn-success", "active");
            btn.classList.add("btn-outline-success");
        });

        button.classList.remove("btn-outline-success");
        button.classList.add("btn-success", "active");

        filterFood();
    });
});



// Display donations when the page opens
displayDonations();
filterFood();
