const donationForm = document.getElementById("donationForm");
const donationMessage = document.getElementById("donationMessage");
const submitDonationBtn = document.getElementById("submitDonationBtn");

const foodPrice = document.getElementById("foodPrice");
const priceContainer = document.getElementById("priceContainer");
const priceAmount = document.getElementById("priceAmount");

// Get the food image input
const foodImage = document.getElementById("food_image");

let isSubmitting = false;

// Show the price field only for paid donations
foodPrice.addEventListener("change", function () {
    if (foodPrice.value === "Paid") {
        priceContainer.classList.remove("d-none");
        priceAmount.disabled = false;
        priceAmount.required = true;
    } else {
        priceContainer.classList.add("d-none");
        priceAmount.disabled = true;
        priceAmount.required = false;
        priceAmount.value = "";
    }
});

// Display messages
function showMessage(message, success) {
    donationMessage.textContent = message;

    donationMessage.className = success
        ? "alert alert-success mt-3"
        : "alert alert-danger mt-3";
}

// Submit donation to PHP
donationForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    if (isSubmitting) {
        return;
    }

    // Collect form values
    const foodName = document.getElementById("foodName").value.trim();
    const category = document.getElementById("foodCategory").value;
    const quantity = Number(document.getElementById("quantity").value);
    const donationType = foodPrice.value;
    const price = priceAmount.value;
    const pickupLocation =
        document.getElementById("pickupLocation").value.trim();
    const donorName = document.getElementById("donorName").value.trim();

    // Validate required fields
    if (!foodName || !category || !pickupLocation || !donorName) {
        showMessage("Please complete all required fields.", false);
        return;
    }

    if (!Number.isInteger(quantity) || quantity < 1) {
        showMessage(
            "Quantity must be a whole number greater than zero.",
            false
        );
        return;
    }

    if (donationType !== "Free" && donationType !== "Paid") {
        showMessage("Please select Free or Paid.", false);
        return;
    }

    if (
        donationType === "Paid" &&
        (
            price.trim() === "" ||
            !Number.isFinite(Number(price)) ||
            Number(price) <= 0
        )
    ) {
        showMessage("Please enter a valid price greater than zero.", false);
        return;
    }

    // Validate the food image
    if (!foodImage || !foodImage.files || foodImage.files.length === 0) {
        showMessage("Please select a food image.", false);
        return;
    }

    const selectedImage = foodImage.files[0];

    const allowedImageTypes = [
        "image/jpeg",
        "image/png",
        "image/webp"
    ];

    if (!allowedImageTypes.includes(selectedImage.type)) {
        showMessage("Only JPG, PNG, and WebP images are allowed.", false);
        return;
    }

    // Maximum image size: 5 MB
    if (selectedImage.size > 5 * 1024 * 1024) {
        showMessage("Image size must not exceed 5 MB.", false);
        return;
    }

    // Prepare data for PHP, including the image
    const formData = new FormData();

    formData.append("foodName", foodName);
    formData.append("category", category);
    formData.append("quantity", quantity);
    formData.append("donationType", donationType);
    formData.append("price", donationType === "Paid" ? price : "0");
    formData.append("pickupLocation", pickupLocation);
    formData.append("donorName", donorName);
    formData.append("food_image", selectedImage);

    // Prevent repeated submissions
    isSubmitting = true;
    submitDonationBtn.disabled = true;
    submitDonationBtn.textContent = "Submitting...";

    try {
        const response = await fetch("backend/save_donation.php", {
            method: "POST",
            body: formData
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(
                result.message || "Could not save the donation."
            );
        }

        showMessage(
            "Thank you, " + donorName +
            "! Your donation of " + foodName +
            " has been saved successfully.",
            true
        );

        // Clear the form after successful database insertion
        donationForm.reset();

        // Hide and disable the price field
        priceContainer.classList.add("d-none");
        priceAmount.disabled = true;
        priceAmount.required = false;

    } catch (error) {
        console.error("Donation error:", error);

        showMessage(
            error.message || "Unable to connect to the server.",
            false
        );
    } finally {
        isSubmitting = false;
        submitDonationBtn.disabled = false;
        submitDonationBtn.textContent = "Submit Donation";
    }
});