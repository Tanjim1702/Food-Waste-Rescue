
const FOOD_STORAGE_KEY = "foodWasteRescueDonations";

// Get saved donations, or use an empty list
function getDonations() {
    try {
        const savedDonations = localStorage.getItem(FOOD_STORAGE_KEY);
        return savedDonations ? JSON.parse(savedDonations) : [];
    } catch (error) {
        console.error("Could not load donations:", error);
        return [];
    }
}


 // Save donations in this browser
function saveDonations(donations) {
    try {
        localStorage.setItem(
            FOOD_STORAGE_KEY,
            JSON.stringify(donations)
        );

        return true;
    } catch (error) {
        console.error("Could not save donations:", error);
        return false;
    }
}



 // Add a new donation to the shared list
function addDonation(donation) {
    const donations = getDonations();

    donation.id = Date.now();
    donations.unshift(donation);

    const saved = saveDonations(donations);

    if (!saved) {
        return false;
    }

    return true;
}

