-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2026 at 04:09 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food_waste_rescue`
--

-- --------------------------------------------------------

--
-- Table structure for table `collection_requests`
--

CREATE TABLE `collection_requests` (
  `id` int(11) NOT NULL,
  `donation_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `quantity_requested` int(11) NOT NULL,
  `status` enum('Pending','Approved','Rejected','Cancelled','Completed') NOT NULL DEFAULT 'Pending',
  `requested_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ;

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `id` int(11) NOT NULL,
  `donor_id` int(11) DEFAULT NULL,
  `food_name` varchar(150) NOT NULL,
  `category` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `quantity_available` int(11) NOT NULL DEFAULT 0,
  `donation_type` enum('Free','Paid') NOT NULL,
  `price` decimal(10,2) DEFAULT 0.00,
  `pickup_location` varchar(255) NOT NULL,
  `donor_name` varchar(150) NOT NULL,
  `status` enum('Available','Partially Reserved','Reserved','Collected') DEFAULT 'Available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `image_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`id`, `donor_id`, `food_name`, `category`, `quantity`, `quantity_available`, `donation_type`, `price`, `pickup_location`, `donor_name`, `status`, `created_at`, `image_path`) VALUES
(1, NULL, 'Fresh Bread', 'bread', 20, 20, 'Free', 0.00, 'Zindabazar, Sylhet', 'Sunrise Bakery', 'Available', '2026-10-27 05:19:54', NULL),
(2, NULL, 'Chicken Biryani', 'meals', 15, 15, 'Paid', 80.00, 'Amberkhana, Sylhet', 'Food Corner Restaurant', 'Available', '2026-10-27 05:39:32', NULL),
(6, NULL, 'mixed vegetable rice', 'meals', 15, 15, 'Free', 0.00, 'Zindabazar, Sylhet', 'Food Corner Restaurant', 'Available', '2026-10-29 05:02:45', 'images/4a9913e74ccfdb728ff8cec39fe8bb27.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('Donor','Receiver','Admin') NOT NULL DEFAULT 'Receiver',
  `organisation_type` varchar(60) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password_hash`, `role`, `organisation_type`, `created_at`) VALUES
(1, 'Tanjim Hussain Sayem-116', 'tanjimhussainsayem@gmail.com', '01628553367', '$2y$10$jfUDhB92Hxwzdvu18jGTK.Ye6h3FJTy4ejlLevoBYpF8JlNBXi1F2', 'Donor', 'Owner', '2026-11-05 04:14:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `collection_requests`
--
ALTER TABLE `collection_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_requests_donation_id` (`donation_id`),
  ADD KEY `idx_requests_receiver_id` (`receiver_id`),
  ADD KEY `idx_requests_status` (`status`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_donations_donor_id` (`donor_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `collection_requests`
--
ALTER TABLE `collection_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `collection_requests`
--
ALTER TABLE `collection_requests`
  ADD CONSTRAINT `fk_requests_donation` FOREIGN KEY (`donation_id`) REFERENCES `donations` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_requests_receiver` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `donations`
--
ALTER TABLE `donations`
  ADD CONSTRAINT `fk_donations_donor` FOREIGN KEY (`donor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
