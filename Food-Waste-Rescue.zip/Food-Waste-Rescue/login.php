
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login | Food Waste Rescue</title>

    <!-- Bootstrap CSS -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
        rel="stylesheet"
    >

    <!-- Existing website CSS -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Login-specific CSS -->
    <link rel="stylesheet" href="css/login.css">
</head>

<body class="login-page">

    <main class="login-container">

        <div class="login-card">

            <!-- Brand Logo -->
            <a href="index.php" class="login-brand">
                <img
                    src="hero-images/leaf-logo.png"
                    alt="Food Waste Rescue Logo"
                >
                <span>Food Waste Rescue</span>
            </a>

            <h1>Login</h1>


            <p class="login-subtitle">
                Welcome back! Please login to your account.
            </p>

            <!-- Login Error Message -->

            <?php if (isset($_GET["error"])): ?>
            <div class="alert alert-danger" role="alert">
                <?php
                    if ($_GET["error"] === "empty") {
                        echo "Please enter your email and password.";
                    } elseif ($_GET["error"] === "invalid") {
                        echo "Invalid email or password.";
                    }
                ?>
                    
                </div>
                <?php endif; ?>

                <!-- Login Form -->
                <form action="backend/login_process.php"
                method="POST">

                <div class="mb-3">

                    <label for="email" class="form-label">
                        Email Address
                    </label>

                    <input
                        type="email"
                        class="form-control"
                        id="email"
                        name="email"
                        placeholder="Enter your email"
                        autocomplete="username"
                        required
                    >

                </div>

                <div class="mb-3">

                    <label for="password" class="form-label">
                        Password
                    </label>

                    <div class="password-wrapper">

                        <input
                            type="password"
                            class="form-control"
                            id="password"
                            name="password"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                            required
                        >

                        <button
                            type="button"
                            id="togglePassword"
                            aria-label="Show password"
                        >
                            <i class="bi bi-eye"></i>
                        </button>

                    </div>

                </div>

                <div class="d-flex justify-content-between
                            align-items-center mb-4">

                    <div class="form-check">

                        <input
                            class="form-check-input"
                            type="checkbox"
                            id="remember"
                            name="remember"
                        >

                        <label
                            class="form-check-label"
                            for="remember"
                        >
                            Remember me
                        </label>

                    </div>

                    <a href="#" class="forgot-link">
                        Forgot password?
                    </a>

                </div>

                <button
                    type="submit"
                    class="btn btn-success w-100 login-button"
                >
                    Login
                </button>

            </form>

            <p class="register-link">
                Don't have an account?
                <a href="register.php">Sign up</a>
            </p>

            <a href="index.php" class="back-home">
                <i class="bi bi-arrow-left"></i>
                Back to Home
            </a>

        </div>

    </main>

    <!-- Password visibility -->
    <script>
        const passwordInput =
            document.getElementById("password");

        const togglePassword =
            document.getElementById("togglePassword");

        togglePassword.addEventListener("click", function () {

            const isPassword =
                passwordInput.type === "password";

            passwordInput.type =
                isPassword ? "text" : "password";

            this.innerHTML = isPassword
                ? '<i class="bi bi-eye-slash"></i>'
                : '<i class="bi bi-eye"></i>';

            this.setAttribute(
                "aria-label",
                isPassword ? "Hide password" : "Show password"
            );

        });
    </script>

</body>
</html>
