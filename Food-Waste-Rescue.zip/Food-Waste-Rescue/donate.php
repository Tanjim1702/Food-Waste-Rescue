
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Donate Food | Food Waste Rescue</title>

    <!-- Bootstrap CSS -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Our CSS file -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold text-success d-flex align-items-center"
   href="index.php">

    <img src="hero-images/leaf-logo.png"
         alt="Food Waste Rescue Logo"
         class="brand-logo">

    <span>Food Waste Rescue</span>

</a>

            <div class="d-flex gap-2">
                <a href="login.php" class="btn btn-outline-success">
                    Login
                </a>
                <a href="index.php" class="btn btn-outline-success">
                    Back to Home
                </a>
            </div>
        </div>
    </nav>

    <!-- Page Heading -->
    <section class="container py-5">

        <div class="text-center mb-5">
            <h1 class="text-success fw-bold">Donate Surplus Food</h1>
            <p class="text-muted">
                Share extra food and help reduce waste in your community.
            </p>
        </div>

        <!-- Donation Form -->
        <div class="row justify-content-center">
            <div class="col-lg-8">

                <div class="card shadow-sm border-0 p-4">

                    <h2 class="h4 text-success mb-4">
                        Food Donation Details
                    </h2>

                    <form id="donationForm">

                        <div class="mb-3">
                            <label for="foodName" class="form-label">
                                Food Name
                            </label>
                            <input
                                type="text"
                                class="form-control"
                                id="foodName"
                                placeholder="e.g. Fresh Bread"
                                required
                            >
                        </div>

                        <div class="mb-3">
                            <label for="foodCategory" class="form-label">
                                Food Category
                            </label>
                            <select
                                class="form-select"
                                id="foodCategory"
                                required
                            >
                                <option value="">Choose a category</option>
                                <option value="vegetables">Vegetables</option>
                                <option value="bread">Bread</option>
                                <option value="meals">Prepared Meals</option>
                                <option value="fruits">Fruits</option>
                                <option value="other">Other</option>
                            </select>
                        </div>

                        <!-- Food Image Upload -->
                        <div class="mb-3">
                            <label for="food_image" class="form-label">Food Image</label>
                            <input type="file"
                                   class="form-control"
                                   id="food_image"
                                   name="food_image"
                                   accept="image/jpeg, image/png, image/webp"
                                   required
                            >
                            <small class="form-text text-muted">Upload a JPG, PNG, or WebP image. Maximum size: 5 MB.</small>
                        </div>

                        <div class="mb-3">
                            <label for="quantity" class="form-label">
                                Quantity
                            </label>
                            <input
                                type="number"
                                class="form-control"
                                id="quantity"
                                min="1"
                                placeholder="e.g. 10"
                                required
                            >
                        </div>

                        <div class="mb-3">
                            <label for="foodPrice" class="form-label">
                                Donation Type
                            </label>
                            <select
                                class="form-select"
                                id="foodPrice"
                                required
                            >
                                <option value="">Choose an option</option>
                                <option value="Free">Free</option>
                                <option value="Paid">Paid</option>
                            </select>
                        </div>
                        <!-- Price field: shown only for paid donations -->
<div class="mb-3 d-none" id="priceContainer">
    <label for="priceAmount" class="form-label">
        Price (৳)
    </label>

    <input
        type="number"
        id="priceAmount"
        class="form-control"
        min="1"
        step="0.01"
        placeholder="Enter the price in taka"
        disabled
    >
</div>

                        <div class="mb-3">
                            <label for="pickupLocation" class="form-label">
                                Pickup Location
                            </label>
                            <input
                                type="text"
                                class="form-control"
                                id="pickupLocation"
                                placeholder="Enter the pickup area"
                                required
                            >
                        </div>

                        <div class="mb-4">
                            <label for="donorName" class="form-label">
                                Donor or Business Name
                            </label>
                            <input
                                type="text"
                                class="form-control"
                                id="donorName"
                                placeholder="Enter your business name"
                                required
                            >
                        </div>

                        <button
    type="submit"
    id="submitDonationBtn"
    class="btn btn-success w-100"
>
    Submit Donation
</button>

                        <p class="text-muted small mt-3 mb-0">
                            Demo form: submissions will not be saved permanently yet.
                        </p>

                    </form>

                    
<div
    id="donationMessage"
    class="alert mt-3 d-none"
    role="status"
    aria-live="polite"
></div>


                </div>

            </div>
        </div>

    </section>

    <!-- Footer -->
    <footer class="text-center py-4">
        <p class="mb-0">
            Food Waste Rescue · Saving food, supporting communities.
        </p>
    </footer>

   <script src="js/food-data.js"></script>
<script src="js/donate.js"></script>

</body>
</html>


