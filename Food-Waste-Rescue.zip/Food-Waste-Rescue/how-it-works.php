
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>How It Works | Food Waste Rescue</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
          rel="stylesheet">

    <!-- Existing Website CSS -->
    <link rel="stylesheet" href="css/style.css">

    <!-- New Page CSS -->
    <link rel="stylesheet" href="css/info-pages.css">
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg bg-white shadow-sm">
    <div class="container">

        <a class="navbar-brand fw-bold text-success d-flex align-items-center"
           href="index.php">

            <img src="hero-images/leaf-logo.png"
                 alt="Food Waste Rescue Logo"
                 class="brand-logo">

            <span>Food Waste Rescue</span>
        </a>

        <button class="navbar-toggler" type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNav"
                aria-controls="navbarNav"
                aria-expanded="false"
                aria-label="Toggle navigation">

            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">

            <ul class="navbar-nav ms-auto align-items-lg-center me-3">

                <li class="nav-item">
                    <a href="index.php" class="nav-link">Home</a>
                </li>

                <li class="nav-item">
                    <a href="how-it-works.php"
                       class="nav-link active">How It Works</a>
                </li>

                <li class="nav-item">
                    <a href="about.php" class="nav-link">About</a>
                </li>

            </ul>

            <div>
                <a href="login.php"
                   class="btn btn-outline-success me-2">Login</a>

                <a href="register.php"
                   class="btn btn-success">Register</a>
            </div>

        </div>
    </div>
</nav>


<!-- PAGE HERO -->
<section class="info-hero">
    <div class="container">
        <div class="row align-items-center">

            <div class="col-md-7">
                <h1>How It Works</h1>

                <p class="lead">
                    A simple process. A big impact.
                </p>

                <p>
                    Food Waste Rescue connects people with surplus food
                    to those who need it. Together, we can reduce food
                    waste and support our community.
                </p>
            </div>

            <div class="col-md-5 text-center">
                <img src="hero-images/how-it-works-hero.jpg"
                alt="how-it-works"
                class="img-fluid rounded shadow">
            </div>

        </div>
    </div>
</section>


<!-- HOW IT WORKS -->
<section class="container py-5">

    <div class="text-center mb-5">
        <h2>Four Simple Steps</h2>
        <p class="text-muted">
            From surplus food to someone who can use it.
        </p>
    </div>

    <div class="row g-4">

        <!-- Step 1 -->
        <div class="col-md-6 col-lg-3">
            <div class="step-card text-center h-100">

                <div class="step-num">1</div>

                <i class="bi bi-shop step-icon"></i>

                <h4>Donate Food</h4>

                <p>
                    Donors register and list their surplus food
                    with its quantity and collection details.
                </p>

            </div>
        </div>

        <!-- Step 2 -->
        <div class="col-md-6 col-lg-3">
            <div class="step-card text-center h-100">

                <div class="step-num">2</div>

                <i class="bi bi-search step-icon"></i>

                <h4>Find Food</h4>

                <p>
                    Receivers browse available food and
                    discover donations in their area.
                </p>

            </div>
        </div>

        <!-- Step 3 -->
        <div class="col-md-6 col-lg-3">
            <div class="step-card text-center h-100">

                <div class="step-num">3</div>

                <i class="bi bi-calendar-check step-icon"></i>

                <h4>Request Collection</h4>

                <p>
                    Receivers select the quantity they need
                    and send a collection request.
                </p>

            </div>
        </div>

        <!-- Step 4 -->
        <div class="col-md-6 col-lg-3">
            <div class="step-card text-center h-100">

                <div class="step-num">4</div>

                <i class="bi bi-heart-fill step-icon"></i>

                <h4>Make an Impact</h4>

                <p>
                    Once the request is approved, the food
                    can be collected and put to good use.
                </p>

            </div>
        </div>

    </div>
</section>


<!-- DONOR AND RECEIVER PROCESS -->
<section class="container pb-5">

    <div class="row g-4">

        <!-- Donors -->
        <div class="col-lg-6">
            <div class="process-card h-100">

                <h2>
                    <i class="bi bi-shop text-success"></i>
                    For Donors
                </h2>

                <ol>
                    <li>
                        <strong>Create a donor account</strong>
                        <p>Register as a Donor using your details.</p>
                    </li>

                    <li>
                        <strong>Post your surplus food</strong>
                        <p>
                            Add the food name, category, quantity,
                            description and pickup location.
                        </p>
                    </li>

                    <li>
                        <strong>Review collection requests</strong>
                        <p>
                            Review requests submitted by Receivers
                            and decide whether to approve them.
                        </p>
                    </li>

                    <li>
                        <strong>Complete the donation</strong>
                        <p>
                            Arrange collection and update the
                            donation status when completed.
                        </p>
                    </li>
                </ol>

            </div>
        </div>

        <!-- Receivers -->
        <div class="col-lg-6">
            <div class="process-card h-100">

                <h2>
                    <i class="bi bi-bag-heart text-success"></i>
                    For Receivers
                </h2>

                <ol>
                    <li>
                        <strong>Create a receiver account</strong>
                        <p>Register as a Receiver using your details.</p>
                    </li>

                    <li>
                        <strong>Browse available food</strong>
                        <p>
                            Explore available food donations and
                            check their details.
                        </p>
                    </li>

                    <li>
                        <strong>Request the food you need</strong>
                        <p>
                            Select the quantity you need and
                            submit a collection request.
                        </p>
                    </li>

                    <li>
                        <strong>Collect your food</strong>
                        <p>
                            Follow the donor's collection
                            instructions after approval.
                        </p>
                    </li>
                </ol>

            </div>
        </div>

    </div>
</section>


<!-- WHY IT MATTERS -->
<section class="why-section py-5">
    <div class="container text-center">

        <h2>Why It Matters</h2>

        <p class="mx-auto" style="max-width: 700px;">
            Good food should feed people, not landfills.
            By connecting donors and receivers, we can reduce
            unnecessary food waste, support people in need,
            and build a more sustainable community.
        </p>

        <a href="register.php" class="btn btn-success btn-lg mt-3">
            Join Food Waste Rescue
        </a>

    </div>
</section>


<!-- FOOTER -->
<footer class="text-center py-4">
    <p class="mb-0">
        Food Waste Rescue · Saving food, supporting communities.
    </p>
</footer>


<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
